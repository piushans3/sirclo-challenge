<?php 

	$id = $_GET['id'];
	$con = new PDO("mysql:host=localhost;dbname=unimedia_kamis","root", "");
	$sql = "DELETE FROM member21116 WHERE id21116 = $id";
	$hasil = $con->prepare($sql);
	$hasil->execute();
	header("Location:index.php");

?>