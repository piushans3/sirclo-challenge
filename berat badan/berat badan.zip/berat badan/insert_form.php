<html>

<h1>Tambah Data Berat Badan</h1>
<hr>
<br>
<form action="insert_proses.php" method="post">
	Tanggal :
	<input type="text" name="Tanggal" placeholder="yyyy-mm-dd">

<br>
	Berat Max :
	<input type="text" name="Max" placeholder="Berat Badan MAX in KG">
<br>
	Berat Min :
	<input type="text" name="Min" placeholder="Berat Badan MIN in KG">
<br>
	Perbedaan :
	<br>
<br>
	<button type="submit">Simpan</button>
</form>
</html