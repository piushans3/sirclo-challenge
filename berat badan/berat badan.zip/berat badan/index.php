<?php 

	$con = new PDO("mysql:host=localhost;dbname=unimedia_kamis","root", "");
	$sql = "SELECT * FROM member21116";
	$hasil = $con->query($sql);
	$hasil->execute();


?>
<html>
<head>

<a href="insert_form.php">Input Data Baru</a>
<h1>Daftar Berat Badan</h1>
<table border="1">
	<tr>

		<th>Tanggal</th>
		<th>Berat Max</th>
		<th>Berat Min</th>
		<th>Perbedaan</th>
		<th>&nbsp Tindakan&nbsp</th>
	</tr>
	<?php 
	$i = 0;
	while ($data = $hasil->fetch()): $i++;
	?>
		<tr>

			<td><?php echo $data['Tanggal']; ?></td>
			<td><?php echo $data['Max']; ?></td>
			<td><?php echo $data['Min']; ?></td>
			<td><?php echo $data['perbedaan']; ?></td>
			<td><a href="edit_form.php?id=<?php echo $data['id21116']; ?>">Edit</a>|<a href="hapus_proses.php?id=<?php echo $data['id21116']; ?>">delete</a></td>
		</tr>
	<?php endwhile; ?>
</table>
</html>
