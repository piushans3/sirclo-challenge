<?php 
	$Tanggal = $_POST['Tanggal'];
	$Max = $_POST['Max'];
	$Min = $_POST['Min'];
	$perbedaan=$_POST['Max']-$_POST['Min'];


	$con = new PDO("mysql:host=localhost;dbname=unimedia_kamis","root", "");
	$sql = "INSERT INTO member21116(Tanggal,Max,Min,perbedaan) VALUES ('$Tanggal','$Max', '$Min', $perbedaan)";

	$hasil = $con->prepare($sql);
	$hasil->execute();
	header("Location:index.php");

?>