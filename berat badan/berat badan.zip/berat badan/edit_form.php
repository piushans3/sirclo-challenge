<?php 
	$id = $_GET['id'];
	$con = new PDO("mysql:host=localhost;dbname=unimedia_kamis","root", "");
	$sql = "SELECT * FROM member21116 WHERE id21116=$id";
	$hasil = $con->query($sql);
	$hasil->execute();
	$data = $hasil->fetch();

?>
<h1>Edit Data</h1>
<form action="edit_proses.php?id=<?php echo $id; ?>" method="post">
<br>
	Tanggal :
	<input type="text" name="Tanggal" placeholder="<?php echo $data['Tanggal']; ?>">
<br>
	Berat Max :
	<input type="text" name="Max" placeholder="<?php echo $data['Max']; ?>">
<br>
	Berat Min :
	<input type="text" name="Min" placeholder="<?php echo $data['Min']; ?>">

<br>
<br>
	<button type="submit">Save</button>
</form>