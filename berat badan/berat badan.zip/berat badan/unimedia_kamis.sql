-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2020 at 06:25 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unimedia_kamis`
--

-- --------------------------------------------------------

--
-- Table structure for table `member21116`
--

CREATE TABLE `member21116` (
  `id21116` int(11) NOT NULL,
  `Tanggal` date NOT NULL,
  `Max` int(3) NOT NULL,
  `Min` int(3) NOT NULL,
  `perbedaan` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member21116`
--

INSERT INTO `member21116` (`id21116`, `Tanggal`, `Max`, `Min`, `perbedaan`) VALUES
(7, '2018-05-23', 55, 12, 43),
(9, '2018-05-11', 54, 53, 1),
(10, '2018-05-09', 76, 65, 11),
(12, '2011-04-05', 88, 55, 33);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `member21116`
--
ALTER TABLE `member21116`
  ADD PRIMARY KEY (`id21116`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `member21116`
--
ALTER TABLE `member21116`
  MODIFY `id21116` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
