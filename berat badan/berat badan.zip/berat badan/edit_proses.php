<?php
	$id = $_GET['id'];
	$con = new PDO("mysql:host=localhost;dbname=unimedia_kamis","root", "");
	$sql = "SELECT * FROM member21116 WHERE id21116 = $id";
	$hasil = $con->query($sql);
	$hasil->execute();
	$data = $hasil->fetch();
	$Tanggal = $_POST['Tanggal'];
	$Max = $_POST['Max'];
	$Min = $_POST['Min'];
	$perbedaan=$_POST['Max']-$_POST['Min'];
	if ($Tanggal=="") {
		$Tanggal = $data['Tanggal'];
	}
	if ($Max=="") {
		$Max = $data['Max'];
	}
	if ($Min=="") {
		$Min = $data['Min'];
	}
	if($perbedaan==""){
		$perbedaan=$data['Max']-$data['Min'];
	}

	$sql2 = "UPDATE member21116 SET Tanggal='$Tanggal',
	Max='$Max',
	Min='$Min',
	perbedaan=$perbedaan
	WHERE id21116=$id";
	$result = $con->prepare($sql2);
	$result->execute();
	header("Location:index.php");

?>